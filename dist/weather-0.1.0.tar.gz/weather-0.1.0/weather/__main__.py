# -*- coding: utf-8 -*-
 
"""
weather.__main__: executed when the weather directory is called as script.
"""

from .cli import cli

cli()