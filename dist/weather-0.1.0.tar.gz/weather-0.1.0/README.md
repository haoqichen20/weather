### weather: a package to get weather information.
---

A general description of weather.

## Installation

```bash
pip install weather
```